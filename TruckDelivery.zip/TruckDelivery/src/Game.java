import javax.swing.JFrame;
import java.util.ArrayList;
import java.util.Random;

public class Game {

	private GUI gui;
	private Board board;
	private EntityCollection entityCollection;
	private ScoreBoard scoreBoard;

	private static int numberOfSquaresX;
	private static int numberOfSquaresY;

	private static final int SCOREBOARDHEIGHT = 200;
	private final int SCOREBOARDWIDTH;

	private static int frameWidth;
	private static int frameHeight;

	private static int squareWidth;
	private static int squareHeight;

	private char packageAndBoxChar = 'A';

	private int numberOfTrucksForAPlayer;
	private int playerTurn = 0;
	private int roundsLeft;
	private int packageLeft;

	private boolean gameOver = false;
	private ArrayList<Player> mPlayers = new ArrayList<Player>();
	private int numberOfPlayers = 2;

	private JFrame frame;

	public Game(JFrame frame, int numberOfSquaresX, int numberOfSquaresY, int numberOfTrucksForAPlayer, int rounds,
			int packages) {
		Game.numberOfSquaresX = numberOfSquaresX;
		Game.numberOfSquaresY = numberOfSquaresY;
		frameWidth = numberOfSquaresX * 100 + 10;
		frameHeight = numberOfSquaresY * 100 + SCOREBOARDHEIGHT;
		SCOREBOARDWIDTH = frameWidth;
		squareWidth = (frameWidth - 10) / numberOfSquaresX;
		squareHeight = (frameHeight - 200) / numberOfSquaresY;

		this.numberOfTrucksForAPlayer = numberOfTrucksForAPlayer;
		roundsLeft = rounds;
		packageLeft = packages;

		board = new Board(numberOfSquaresX, numberOfSquaresY, squareWidth, squareHeight);
		entityCollection = new EntityCollection();
		addPlayersAndTrucksAndCrossHairs();
		scoreBoard = new ScoreBoard(mPlayers, this, SCOREBOARDWIDTH, SCOREBOARDHEIGHT);
		gui = new GUI(entityCollection, board, scoreBoard);

		this.frame = frame;
		this.frame.setBounds(10, 10, frameWidth, frameHeight);
		this.frame.add(gui);
		new Controller(this, gui);
		startGame();
	}

	private void startGame() {
		mPlayers.get(playerTurn).setMyTurn(true);
		for (int i = 0; i < packageLeft; i++) {
			randomSpawnPackagesAndPostBoxes();
		}
	}

	private void addPlayersAndTrucksAndCrossHairs() {
		for (int team = 1; team <= numberOfPlayers; team++) {
			CrossHair crossHair = new CrossHair(team);
			entityCollection.addEntity(crossHair);
			mPlayers.add(new Player(team, crossHair, board));

			for (int j = 1; j <= numberOfTrucksForAPlayer; j++) {
				Truck truck = new Truck(team, j);
				entityCollection.addEntity(truck);
				mPlayers.get(team - 1).addTrucks(truck);
			}
		}
	}

	// called when keyPressed
	public void events() {
		entityCollection.removeDeadEntities();
		board.setColorOfSquares(mPlayers.get(playerTurn));
		scoreBoard.update();
		gui.repaint();
	}

	public void nextRound() {
		if (roundsLeft > 0) {
			mPlayers.get(playerTurn).nextRound();

			playerTurn++;
			if (playerTurn >= numberOfPlayers) {
				playerTurn = 0;
				mPlayers.get(playerTurn).setMyTurn(true);
				for (Truck truck : mPlayers.get(playerTurn).getmTrucks()) {
					truck.setTurnOver(false);
				}
			} else {
				mPlayers.get(playerTurn).setMyTurn(true);
				for (Truck truck : mPlayers.get(playerTurn).getmTrucks()) {
					truck.setTurnOver(false);
				}
			}

			roundsLeft--;
		}
		if (roundsLeft == 0) {
			gui.setVisible(false);
			gameOver();
		}
	}

	private void gameOver() {
		new GameOver(frame, scoreBoard, frameWidth, frameHeight);
	}

	private ArrayList<ArrayList<Square>> getSquaresWithNoPostBoxesOrPackages() {

		ArrayList<ArrayList<Square>> pairSquares = new ArrayList<ArrayList<Square>>();

		for (int i = 0; i < board.getmSquares().size(); i++) {
			// two squares that is inverted must not have PostBox Or Package in squares:
			if (!board.getmSquares().get(i).isHasPostBoxOrPacket()
					&& !board.getmSquares().get((board.getmSquares().size() - 1) - i).isHasPostBoxOrPacket()) {
				ArrayList<Square> squares = new ArrayList<Square>();
				squares.add(board.getmSquares().get(i));
				squares.add(board.getmSquares().get(board.getmSquares().size() - 1 - i));
				// adds pair with squares:
				pairSquares.add(squares);
			}
		}
		return pairSquares;
	}

	private ArrayList<Square> getRandomSquares(ArrayList<ArrayList<Square>> pairSquares) {
		Random random = new Random();
		// returns a pair of squares:
		return pairSquares.get(random.nextInt(pairSquares.size()));
	}

	private boolean checkIfAbleToSpawnTwoPackagesAndPostBoxes() {
		for (int i = 0; i < board.getmSquares().size(); i++) {
			if (!board.getmSquares().get(i).isHasPostBoxOrPacket()
					&& !board.getmSquares().get((board.getmSquares().size() - 1) - i).isHasPostBoxOrPacket()) {

				for (int j = i + 1; j < board.getmSquares().size(); j++) {
					if (!board.getmSquares().get(j).isHasPostBoxOrPacket()
							&& !board.getmSquares().get((board.getmSquares().size() - 1) - j).isHasPostBoxOrPacket()) {
						return true;
					}
				}
			}
		}
		return false;
	}

	// Guarantees, spawning two Packet's and two MailBoxes in symmetric positions of
	// the Board
	private void randomSpawnPackagesAndPostBoxes() {
		if (checkIfAbleToSpawnTwoPackagesAndPostBoxes() && packageLeft > 0) {
			char tempChar = packageAndBoxChar;
			tempChar++;

			ArrayList<Square> squares = getRandomSquares(getSquaresWithNoPostBoxesOrPackages());
			PostPackage postPackage = new PostPackage(squares.get(0).getPosX(), squares.get(0).getPosY(),
					packageAndBoxChar);
			entityCollection.addEntity(postPackage);
			squares.get(0).setPackage(postPackage);
			squares.get(0).setHasPostBoxOrPackage(true);

			postPackage = new PostPackage(squares.get(1).getPosX(), squares.get(1).getPosY(), tempChar);
			entityCollection.addEntity(postPackage);
			squares.get(1).setPackage(postPackage);
			squares.get(1).setHasPostBoxOrPackage(true);

			squares = getRandomSquares(getSquaresWithNoPostBoxesOrPackages());
			PostBox postBox = new PostBox(squares.get(0).getPosX(), squares.get(0).getPosY(), (packageAndBoxChar));
			entityCollection.addEntity(postBox);
			squares.get(0).setPostBox(postBox);
			squares.get(0).setHasPostBoxOrPackage(true);

			postBox = new PostBox(squares.get(1).getPosX(), squares.get(1).getPosY(), tempChar);
			entityCollection.addEntity(postBox);
			squares.get(1).setPostBox(postBox);
			squares.get(1).setHasPostBoxOrPackage(true);

			packageAndBoxChar += 2;
			packageLeft--;
		}
	}

	public static int getSQUAREWIDTH() {
		return squareWidth;
	}

	public static int getSQUAREHEIGHT() {
		return squareHeight;
	}

	public static int getNUMBEROFSQUARESX() {
		return numberOfSquaresX;
	}

	public static int getNUMBEROFSQUARESY() {
		return numberOfSquaresY;
	}

	public ArrayList<Player> getmPlayers() {
		return mPlayers;
	}

	public int getNumberOfPlayers() {
		return numberOfPlayers;
	}

	public int getPlayerTurn() {
		return playerTurn;
	}

	public boolean getgameOver() {
		return gameOver;
	}

	public int getRoundsLeft() {
		return roundsLeft;
	}
}
