import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Controller implements KeyListener {
	private Game game;

	public Controller(Game game, GUI gui) {
		this.game = game;
		gui.addKeyListener(this);
		gui.requestFocusInWindow();
	}

	// In the functions below, game.getPlayerTurn() == the index of the ArrayList
	// game.mPlayers. this is a way to avoid a for loop, to check who's turn it is
	private void moveCrossHairUp() {
		game.getmPlayers().get(game.getPlayerTurn()).crossHairUp();
	}

	private void moveCrossHairDown() {
		game.getmPlayers().get(game.getPlayerTurn()).crossHairDown();
	}

	private void moveCrossHairRight() {
		game.getmPlayers().get(game.getPlayerTurn()).crossHairRight();
	}

	private void moveCrossHairLeft() {
		game.getmPlayers().get(game.getPlayerTurn()).crossHairLeft();
	}

	private void trySelectTruck() {
		game.getmPlayers().get(game.getPlayerTurn()).trySelectTruck();
	}

	private void tryMoveTruck() {
		game.getmPlayers().get(game.getPlayerTurn()).tryMoveTruckToSquare();
	}
	///////////////////////////////////////////////////////////////////////////////////

	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			moveCrossHairRight();
		} else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			moveCrossHairLeft();
		} else if (e.getKeyCode() == KeyEvent.VK_UP) {
			moveCrossHairUp();
		} else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
			moveCrossHairDown();
		} else if (e.getKeyCode() == KeyEvent.VK_SPACE) {
			tryMoveTruck();
			trySelectTruck();
		} else if (e.getKeyCode() == KeyEvent.VK_ENTER) {
			game.nextRound();
		}
		game.events();
	}

	public void keyReleased(KeyEvent e) {
	}

	public void keyTyped(KeyEvent e) {
	}
}
