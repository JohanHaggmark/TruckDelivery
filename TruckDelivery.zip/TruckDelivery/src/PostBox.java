import java.awt.Image;
import javax.swing.ImageIcon;

public class PostBox implements OnPlayground {

	private int posX;
	private int posY;
	//info is a char that match with a PostPackage's info
	private String info;
	private boolean visible;
	private boolean removeMe = false;
	private Image postBoxImage;

	public PostBox(int posX, int posY, char info) {
		this.posX = posX;
		this.posY = posY;
		this.info = "" + info;
		visible = true;

		ImageIcon postBoxIcon = new ImageIcon(getClass().getResource("PostBox.png"));
		postBoxImage = postBoxIcon.getImage();
	}

	@Override
	public int getPosX() {
		return posX;
	}

	@Override
	public int getPosY() {
		return posY;
	}

	@Override
	public void setPosX(int posX) {
		this.posX = posX;
	}

	@Override
	public void setPosY(int posY) {
		this.posY = posY;
	}

	@Override
	public Image getEntityImage() {
		return postBoxImage;
	}

	@Override
	public String getEntityInfo() {
		return info;
	}

	public boolean isVisible() {
		return visible;
	}

	public void setVisible(boolean alive) {
		this.visible = alive;
	}

	public boolean isRemoveMe() {
		return removeMe;
	}

	public void setRemoveMe(boolean removeMe) {
		this.removeMe = removeMe;
	}

	@Override
	public int getInfoPosX() {
		return 5;
	}

	@Override
	public int getInfoPosY() {
		return 30;
	}
}
